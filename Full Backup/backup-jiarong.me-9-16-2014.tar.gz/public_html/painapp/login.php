<?php
	header('Content-Type: application/json');
	define('DIRECTORY_SEPARATOR', '/../wordpress/');

	require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . '/wordpress/wp-blog-header.php');

	require_once('/home/jiarhcah/public_html/painapp/api/login.php');

	$response = array("status" => "ok", "tag" => "", "success" => 0, "error" => 0);

	$response['success'] = 0;
	$response['error'] = 0;

	if(!user_pass_ok("holyxiaoxin","sunshine")){
		$response['success'] = 1;
	}else{
		$response['error'] = 1;
	}

	echo json_encode($response);
?>