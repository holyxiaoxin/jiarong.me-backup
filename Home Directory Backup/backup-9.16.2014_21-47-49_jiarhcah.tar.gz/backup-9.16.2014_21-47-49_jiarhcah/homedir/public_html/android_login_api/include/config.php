<?php

/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "jiarhcah_public");
define("DB_PASSWORD", "public123");
define("DB_DATABASE", "jiarhcah_android_api");
?>
