<?php

	// require_once('/home/jiarhcah/public_html/painapp/wordpress/wp-includes/registration.php');

	// $user_name = "new_user";
	// $user_email = "email@email.com";

	// $user_id = username_exists( $user_name );
	
	// if ( !$user_id ) {
	// 	$random_password = wp_generate_password( 12, false );
	// 	$user_id = wp_create_user( $user_name, $random_password, $user_email );
	// }else{
	// 	$random_password = __('User already exists.  Password inherited.');
	// }


	require_once('/home/jiarhcah/public_html/painapp/wordpress/wp-blog-header.php');

	$email = "abc@abc.abc";
	$username = "holyxiaoxin3";
	$password = "password";

	$result = wp_create_user($username, $password, $email);

	if ( is_wp_error( $result ) ) {
	   $error_string = $result->get_error_message();
	   echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
	}else{
		echo 'user succesfully created';
	}


?>