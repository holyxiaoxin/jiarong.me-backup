-- cPanel mysql backup
GRANT USAGE ON *.* TO 'jiarhcah'@'localhost' IDENTIFIED BY PASSWORD '*ED4FCD7A1D30E1D7E2CB11DB96285A1490233324';
GRANT ALL PRIVILEGES ON `jiarhcah\_android\_api`.* TO 'jiarhcah'@'localhost';
GRANT ALL PRIVILEGES ON `jiarhcah\_wp244`.* TO 'jiarhcah'@'localhost';
GRANT USAGE ON *.* TO 'jiarhcah_public'@'localhost' IDENTIFIED BY PASSWORD '*1904243F5772619C8BF5DC6170B596E9494F85F1';
GRANT ALL PRIVILEGES ON `jiarhcah\_android\_api`.* TO 'jiarhcah_public'@'localhost';
GRANT USAGE ON *.* TO 'jiarhcah_wp244'@'localhost' IDENTIFIED BY PASSWORD '*EFEC92CBA37FB9FA403DA15E9F749B064678A84E';
GRANT ALL PRIVILEGES ON `jiarhcah\_wp244`.* TO 'jiarhcah_wp244'@'localhost';
